#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif
#define MAGICKCORE_HDRI_ENABLE 0
#define MAGICKCORE_QUANTUM_DEPTH 8
#import "MagickWand/MagickWand.h"
FOUNDATION_EXPORT double ImageMagick7VersionNumber;
FOUNDATION_EXPORT const unsigned char ImageMagick7VersionString[];

