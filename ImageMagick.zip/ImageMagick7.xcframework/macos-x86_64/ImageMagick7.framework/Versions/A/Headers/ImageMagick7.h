//  ImageMagick7.h
//  ImageMagick7
//
//
//  Created by Dmytro Medynskyi on 19.04.2021.
//

#import <Foundation/Foundation.h>

//! Project version number for ImageMagick7.
FOUNDATION_EXPORT double ImageMagick7VersionNumber;

//! Project version string for ImageMagick7.
FOUNDATION_EXPORT const unsigned char ImageMagick7VersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ImageMagick7/PublicHeader.h>


